import { commerceFeatures } from "@/content/site-content";
import { trackCta } from "@/lib/analytics";
import { setLeadIntent } from "@/lib/lead-intent";
import ProductTabs from "./ProductTabs";
import { ArrowIcon, FeatureGrid, SectionHeader, StatusBadge } from "./shared";

function CommercePreview() {
  return (
    <div className="interface-frame interface-frame--commerce">
      <div className="interface-frame__header">
        <span className="sample-label">Example configured interface</span>
        <span className="mock-brand">
          Aster Fine Jewelry <small>Fictional brand</small>
        </span>
      </div>
      <ProductTabs
        label="Commerce interface views"
        tabs={[
          {
            label: "Product",
            content: (
              <div className="commerce-view commerce-product">
                <div
                  className="commerce-product__image"
                  aria-label="Synthetic sample ring product render"
                  role="img"
                >
                  <i />
                  <span />
                </div>
                <div>
                  <p className="mock-kicker">Made to order</p>
                  <h3>Arc solitaire ring</h3>
                  <p className="mock-price">Example price · $3,850</p>
                  <div className="mock-options">
                    <span>18K yellow gold</span>
                    <span>Emerald</span>
                    <span>1.5 ct</span>
                  </div>
                  <div className="mock-actions">
                    <span>Customize</span>
                    <span>Try on</span>
                  </div>
                </div>
              </div>
            ),
          },
          {
            label: "Configuration",
            content: (
              <div className="commerce-view configuration-view">
                <div className="flow-stack">
                  <span>Style · ARC-01</span>
                  <i>→</i>
                  <span>Valid options</span>
                  <i>→</i>
                  <span>CF-8A21 selection</span>
                </div>
                <dl>
                  <div>
                    <dt>Metal</dt>
                    <dd>18K yellow gold</dd>
                  </div>
                  <div>
                    <dt>Band</dt>
                    <dd>Standard</dd>
                  </div>
                  <div>
                    <dt>Center stone</dt>
                    <dd>Emerald · 1.5 ct</dd>
                  </div>
                  <div>
                    <dt>Readiness</dt>
                    <dd>Quote required</dd>
                  </div>
                </dl>
              </div>
            ),
          },
          {
            label: "Purchase",
            content: (
              <div className="commerce-view purchase-view">
                <p className="mock-kicker">Configured purchase path</p>
                <h3>Choose the next commercial action</h3>
                <div className="purchase-options">
                  <span>Request a quote</span>
                  <span>Book an appointment</span>
                  <span>Continue to cart</span>
                </div>
                <small>Available actions depend on the approved storefront and providers.</small>
              </div>
            ),
          },
        ]}
      />
    </div>
  );
}

export default function CommerceSection() {
  return (
    <section
      className="commerce-section section section--stone"
      id="commerce"
      aria-labelledby="commerce-title"
    >
      <div className="shell">
        <div className="product-title-row">
          <SectionHeader
            eyebrow="CARATFLOW COMMERCE"
            title="Turn interactive discovery into a connected storefront."
          >
            <p>
              CaratFlow Commerce is the storefront layer for deployments that connect customization
              and try-on with approved product data and a purchase path. It can complement an
              existing site or support a new jewelry storefront after technical review.
            </p>
          </SectionHeader>
          <StatusBadge status="Configured deployment" />
        </div>
        <div className="product-split product-split--media-first">
          <CommercePreview />
          <FeatureGrid features={commerceFeatures} />
        </div>
        <div className="section-outcome">
          <p>
            <span>Outcome</span> Reduce unnecessary handoffs between product exploration and the
            next commercial action.
          </p>
          <a
            className="button button--primary"
            href="#demo"
            onClick={() => {
              setLeadIntent({ modules: ["Commerce"] });
              trackCta("commerce");
            }}
          >
            Discuss CaratFlow Commerce <ArrowIcon />
          </a>
        </div>
      </div>
    </section>
  );
}
